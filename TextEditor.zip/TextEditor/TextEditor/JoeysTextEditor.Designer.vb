﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class JoeysTextEditor
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Me.tbEditBox = New System.Windows.Forms.TextBox()
		Me.mnuHeader = New System.Windows.Forms.MenuStrip()
		Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileNew = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileSaveAs = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuEditCopy = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuEditCut = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
		Me.ttpEditHelp = New System.Windows.Forms.ToolTip(Me.components)
		Me.opdFileOpen = New System.Windows.Forms.OpenFileDialog()
		Me.sfdSave = New System.Windows.Forms.SaveFileDialog()
		Me.mnuHeader.SuspendLayout()
		Me.SuspendLayout()
		'
		'tbEditBox
		'
		Me.tbEditBox.Dock = System.Windows.Forms.DockStyle.Fill
		Me.tbEditBox.Location = New System.Drawing.Point(0, 28)
		Me.tbEditBox.Multiline = True
		Me.tbEditBox.Name = "tbEditBox"
		Me.tbEditBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
		Me.tbEditBox.Size = New System.Drawing.Size(434, 329)
		Me.tbEditBox.TabIndex = 0
		'
		'mnuHeader
		'
		Me.mnuHeader.ImageScalingSize = New System.Drawing.Size(20, 20)
		Me.mnuHeader.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuHelp})
		Me.mnuHeader.Location = New System.Drawing.Point(0, 0)
		Me.mnuHeader.Name = "mnuHeader"
		Me.mnuHeader.Size = New System.Drawing.Size(434, 28)
		Me.mnuHeader.TabIndex = 1
		Me.mnuHeader.Text = "MenuStrip1"
		'
		'mnuFile
		'
		Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileNew, Me.mnuFileOpen, Me.mnuFileSave, Me.mnuFileSaveAs, Me.mnuFileExit})
		Me.mnuFile.Name = "mnuFile"
		Me.mnuFile.Size = New System.Drawing.Size(46, 24)
		Me.mnuFile.Text = "&File"
		'
		'mnuFileNew
		'
		Me.mnuFileNew.Name = "mnuFileNew"
		Me.mnuFileNew.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
		Me.mnuFileNew.Size = New System.Drawing.Size(224, 26)
		Me.mnuFileNew.Text = "&New"
		Me.mnuFileNew.ToolTipText = "Make a new text file."
		'
		'mnuFileOpen
		'
		Me.mnuFileOpen.Name = "mnuFileOpen"
		Me.mnuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
		Me.mnuFileOpen.Size = New System.Drawing.Size(224, 26)
		Me.mnuFileOpen.Text = "&Open"
		Me.mnuFileOpen.ToolTipText = "Open a saved text file."
		'
		'mnuFileSave
		'
		Me.mnuFileSave.Name = "mnuFileSave"
		Me.mnuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
		Me.mnuFileSave.Size = New System.Drawing.Size(224, 26)
		Me.mnuFileSave.Text = "&Save"
		Me.mnuFileSave.ToolTipText = "Save the current file."
		'
		'mnuFileSaveAs
		'
		Me.mnuFileSaveAs.Name = "mnuFileSaveAs"
		Me.mnuFileSaveAs.Size = New System.Drawing.Size(224, 26)
		Me.mnuFileSaveAs.Text = "Save &As"
		Me.mnuFileSaveAs.ToolTipText = "Save the current file."
		'
		'mnuFileExit
		'
		Me.mnuFileExit.Name = "mnuFileExit"
		Me.mnuFileExit.Size = New System.Drawing.Size(224, 26)
		Me.mnuFileExit.Text = "E&xit"
		Me.mnuFileExit.ToolTipText = "Exit the text editor."
		'
		'mnuEdit
		'
		Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditCopy, Me.mnuEditCut, Me.mnuEditPaste})
		Me.mnuEdit.Name = "mnuEdit"
		Me.mnuEdit.Size = New System.Drawing.Size(49, 24)
		Me.mnuEdit.Text = "&Edit"
		'
		'mnuEditCopy
		'
		Me.mnuEditCopy.Name = "mnuEditCopy"
		Me.mnuEditCopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
		Me.mnuEditCopy.Size = New System.Drawing.Size(177, 26)
		Me.mnuEditCopy.Text = "&Copy"
		Me.mnuEditCopy.ToolTipText = "Copy selected text."
		'
		'mnuEditCut
		'
		Me.mnuEditCut.Name = "mnuEditCut"
		Me.mnuEditCut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
		Me.mnuEditCut.Size = New System.Drawing.Size(177, 26)
		Me.mnuEditCut.Text = "Cu&t"
		Me.mnuEditCut.ToolTipText = "Cut selected text."
		'
		'mnuEditPaste
		'
		Me.mnuEditPaste.Name = "mnuEditPaste"
		Me.mnuEditPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
		Me.mnuEditPaste.Size = New System.Drawing.Size(177, 26)
		Me.mnuEditPaste.Text = "&Paste"
		Me.mnuEditPaste.ToolTipText = "Paste selected text."
		'
		'mnuHelp
		'
		Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpAbout})
		Me.mnuHelp.Name = "mnuHelp"
		Me.mnuHelp.Size = New System.Drawing.Size(55, 24)
		Me.mnuHelp.Text = "&Help"
		'
		'mnuHelpAbout
		'
		Me.mnuHelpAbout.Name = "mnuHelpAbout"
		Me.mnuHelpAbout.ShortcutKeys = System.Windows.Forms.Keys.F1
		Me.mnuHelpAbout.Size = New System.Drawing.Size(157, 26)
		Me.mnuHelpAbout.Text = "&About"
		Me.mnuHelpAbout.ToolTipText = "Shows about."
		'
		'opdFileOpen
		'
		Me.opdFileOpen.FileName = "OpenFileDialog1"
		'
		'sfdSave
		'
		Me.sfdSave.Filter = "Plain Text (*.txt)|*.txt|All Files (*.*)|*.*"
		'
		'JoeysTextEditor
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(434, 357)
		Me.Controls.Add(Me.tbEditBox)
		Me.Controls.Add(Me.mnuHeader)
		Me.MainMenuStrip = Me.mnuHeader
		Me.Name = "JoeysTextEditor"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Joey's Text Editor"
		Me.mnuHeader.ResumeLayout(False)
		Me.mnuHeader.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents tbEditBox As TextBox
	Friend WithEvents mnuHeader As MenuStrip
	Friend WithEvents mnuFile As ToolStripMenuItem
	Friend WithEvents mnuFileNew As ToolStripMenuItem
	Friend WithEvents mnuFileOpen As ToolStripMenuItem
	Friend WithEvents mnuFileSave As ToolStripMenuItem
	Friend WithEvents mnuFileSaveAs As ToolStripMenuItem
	Friend WithEvents mnuFileExit As ToolStripMenuItem
	Friend WithEvents mnuEdit As ToolStripMenuItem
	Friend WithEvents mnuEditCopy As ToolStripMenuItem
	Friend WithEvents mnuEditCut As ToolStripMenuItem
	Friend WithEvents mnuEditPaste As ToolStripMenuItem
	Friend WithEvents mnuHelp As ToolStripMenuItem
	Friend WithEvents mnuHelpAbout As ToolStripMenuItem
	Friend WithEvents ttpEditHelp As ToolTip
	Friend WithEvents opdFileOpen As OpenFileDialog
	Friend WithEvents sfdSave As SaveFileDialog
End Class
