﻿' Author: Joey Chan
' Modified: April 30rd, 2020
' Description: A text editor which can allow users to cut, copy, and 
'              paste text inside a textbox. Text can also be saved 
'              into a txt file And loaded later.

' Some code was used from the "Whiteboard Demo" by Kyle Chapman.

Option Strict On
Imports System.IO
Public Class JoeysTextEditor
    Dim openFilePath As String = String.Empty

    ' The New menu item. This will clear any text within the textbox
    ' and clear any variables that were used as well. 
    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click
        tbEditBox.Clear()
        openFilePath = String.Empty
        Me.Text = "Joey's Text Editor"
    End Sub

    ' The Open menu item will allow the user to choose a file on their
    ' Computer to open and work on.
    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        Dim openFile As FileStream
        Dim fileReader As StreamReader

        ' If a file is successfully opened
        If opdFileOpen.ShowDialog() = DialogResult.OK Then
            openFilePath = opdFileOpen.FileName

            openFile = New FileStream(openFilePath, FileMode.Open, FileAccess.Read)
            fileReader = New StreamReader(openFile)

            'Populates the textbox with file's content.
            tbEditBox.Text = fileReader.ReadToEnd

            'Closes the fileReader
            fileReader.Close()

            Me.Text = "Joey's Text Editor - " & openFilePath
        End If

    End Sub

    ' The about menu item just brings up the about messagebox which
    ' shows the form's information which is the name, the creator 
    ' and the date it was modified.
    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        MessageBox.Show("Joey's Text Editor" & vbCrLf & vbCrLf & "By: Joey Chan" & vbCrLf & vbCrLf & "April 3rd, 2020")
    End Sub

    ' The save menu item saves any work in the textbox to a file 
    ' If it Is already being worked on. If there is no saved file,
    ' it will behave the same way as save as.
    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        ' Checks if a file has already been saved or not.
        If openFilePath = String.Empty Then
            ' Runs save as
            mnuFileSaveAs_Click(sender, e)
        Else
            ' Saves the file without the need for a dialog.
            SaveFile(openFilePath)
        End If
    End Sub

    ' The save as menu item will allow the user to choose where
    ' to save their file. 
    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click
        'If the file was saved
        If sfdSave.ShowDialog() = DialogResult.OK Then
            sfdSave.Filter = "Text Documents (*.txt) |All Files"
            ' Set the new filePath
            openFilePath = sfdSave.FileName
            ' Save the file to the new filepath
            SaveFile(openFilePath)
        End If
    End Sub

    ' This just exits the form.
    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    ' This copies and selected text.
    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click
        CopyText(tbEditBox)
    End Sub

    ' This cuts the selected text and adds it to the clipboard.
    Private Sub mnuEditCut_Click(sender As Object, e As EventArgs) Handles mnuEditCut.Click
        CutText(tbEditBox)
    End Sub

    ' This inserts the text in the clipboard to the specified location.
    Private Sub mnuEditPaste_Click(sender As Object, e As EventArgs) Handles mnuEditPaste.Click
        PasteText(tbEditBox)
    End Sub

    ' This method allows for saving to take place.
    Sub SaveFile(filepath As String)
        Dim fileStream As New FileStream(filepath, FileMode.Create, FileAccess.Write)
        Dim fileWriter As New StreamWriter(fileStream)

        ' Save whatever was in the textbox to the file.
        fileWriter.Write(tbEditBox.Text)

        ' Stops the fileWriter
        fileWriter.Close()

        Me.Text = "Joey's Text Editor - " & filepath
    End Sub

    ' This method is used for copying.
    Sub CopyText(textbox As TextBox)
        Clipboard.SetText(textbox.SelectedText)
    End Sub

    ' This method is used for cutting text.
    Sub CutText(textbox As TextBox)
        Clipboard.SetText(textbox.SelectedText)
        textbox.SelectedText = String.Empty
    End Sub

    ' This method is used for pasting text.
    Sub PasteText(textbox As TextBox)
        textbox.Paste(Clipboard.GetText())
    End Sub
End Class
